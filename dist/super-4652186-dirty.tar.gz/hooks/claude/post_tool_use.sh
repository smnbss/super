#!/usr/bin/env bash
# super/hooks/claude/post_tool_use.sh
# Post-tool validation hook

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export SUPER_HOME="${SUPER_HOME:-$(cd "$SCRIPT_DIR/../.." && pwd)}"
source "$SUPER_HOME/lib/config.sh"
source "$SUPER_HOME/lib/validators.sh"
source "$SUPER_HOME/lib/session.sh"

INPUT="$(cat)"

# Only process if postToolUse hook is enabled
if ! _super_config_enabled "hooks.postToolUse.enabled"; then
  exit 0
fi

# Extract tool info
TOOL_NAME="$(echo "$INPUT" | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d.get("tool_name",""))' 2>/dev/null || echo "")"

# Log the tool use to session
if _super_config_enabled "session.sessionLog"; then
  session_append_turn "Claude Code" "tool" "$TOOL_NAME"
fi

# Run validators if configured
if _super_config_enabled "hooks.postToolUse.runValidators"; then
  if _super_should_validate "$TOOL_NAME"; then
    _super_run_validators || true  # Don't block on validation failure
  fi
fi

exit 0
